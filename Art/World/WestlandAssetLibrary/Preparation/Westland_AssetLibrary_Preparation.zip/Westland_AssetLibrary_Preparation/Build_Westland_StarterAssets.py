"""PokeMonster Westland: procedural Blender STARTER geometry, not final art.
Blender 4.3+/5.x. Run: blender -b -t 4 --python Build_Westland_StarterAssets.py -- /absolute/output/Westland_StarterAssets.blend
Does not modify Unreal, export FBX or touch existing project files.
"""
import bpy, math, random, sys
from mathutils import Vector
from pathlib import Path

R=random.Random(38117)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name!='Collection' and c.users==0: bpy.data.collections.remove(c)

# Blender uses metres; world Z up. Materials are preview shaders and must be
# baked/replaced with stylised hand-painted maps before Unreal integration.
def mat(name, color, shade=None):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1);m.use_nodes=True
    n=m.node_tree.nodes; links=m.node_tree.links; p=n.get('Principled BSDF')
    p.inputs['Roughness'].default_value=.86
    noise=n.new('ShaderNodeTexNoise'); noise.inputs['Scale'].default_value=7.0;noise.inputs['Detail'].default_value=2.1;noise.inputs['Roughness'].default_value=.6
    ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.22;ramp.color_ramp.elements[1].position=.82
    low=shade or tuple(max(.01,x*.75) for x in color)
    ramp.color_ramp.elements[0].color=(*low,1);ramp.color_ramp.elements[1].color=(*color,1)
    links.new(noise.outputs['Fac'],ramp.inputs[0]);links.new(ramp.outputs['Color'],p.inputs['Base Color'])
    return m
WOOD=mat('WL_Preview_Wood',(0.42,.235,.12)); BARK=mat('WL_Preview_Bark',(.33,.22,.15))
WOODLIGHT=mat('WL_Preview_WoodLight',(.57,.38,.23));LEAF=mat('WL_Preview_Leaf',(.24,.39,.17))
LEAF2=mat('WL_Preview_LeafWarm',(.39,.49,.21)); GRASS=mat('WL_Preview_Grass',(.35,.49,.18))
GRASS2=mat('WL_Preview_GrassDry',(.59,.52,.26));STONE=mat('WL_Preview_Stone',(.48,.46,.39))
STONE2=mat('WL_Preview_StoneMoss',(.37,.41,.34)); METAL=mat('WL_Preview_Iron',(.18,.19,.18))
FLOWER=mat('WL_Preview_Flower',(.86,.77,.51));PURPLE=mat('WL_Preview_Purple',(.65,.43,.64))
STRAW=mat('WL_Preview_Straw',(.68,.54,.29)); RED=mat('WL_Preview_Berry',(.66,.2,.13))

root=bpy.data.collections.new('WL_StarterAssets__REVIEW_ONLY');bpy.context.scene.collection.children.link(root)
active=None; objects={}
def start(name):
    global active
    active=bpy.data.collections.new('WL_'+name);root.children.link(active);objects[name]=[]
def put(o,ma=None):
    for c in list(o.users_collection):c.objects.unlink(o)
    active.objects.link(o)
    if ma:o.data.materials.append(ma)
    objects[active.name[3:]].append(o)
    return o

def cube(name,loc,scale,ma,bevel=.035):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    put(o,ma)
    if bevel:
        mod=o.modifiers.new('Handworked_soft_edges','BEVEL');mod.width=min(bevel,min(scale)*.16);mod.segments=2
        o.modifiers.new('WeightedNormals','WEIGHTED_NORMAL')
    return o

def cyl(name,loc,r,depth,ma,vertices=10,rotation=None):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices,radius1=r,radius2=r*.86,depth=depth,location=loc)
    o=bpy.context.object;o.name=name;put(o,ma)
    if rotation:o.rotation_euler=rotation
    return o

def ico(name,loc,scale,ma,sub=1,rough=.13):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub,radius=1,location=loc);o=bpy.context.object;o.name=name
    for v in o.data.vertices:
        f=1+R.uniform(-rough,rough);v.co*=f
    o.scale=scale;put(o,ma);return o

def beam_between(name,a,b,r,ma,vertices=8):
    a,b=Vector(a),Vector(b);d=b-a
    o=cyl(name,(a+b)*.5,r,d.length,ma,vertices);o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o

def leaf(name,base,tip,width,ma):
    base,tip=Vector(base),Vector(tip);d=tip-base
    side=d.cross(Vector((0,0,1))).normalized() if abs(d.normalized().z)<.98 else Vector((1,0,0))
    mid=base+d*.55+Vector((0,0,.025));verts=[base,mid+side*width,tip,mid-side*width,mid+Vector((0,0,width*.18))]
    mesh=bpy.data.meshes.new(name+'_mesh');mesh.from_pydata(verts,[],[(0,1,4),(1,2,4),(2,3,4),(3,0,4)]);mesh.update()
    ob=bpy.data.objects.new(name,mesh);active.objects.link(ob);objects[active.name[3:]].append(ob);mesh.materials.append(ma)
    return ob

def trunk_tree(name,height=8,radius=.35,spread=3.0,clusters=9,lean=.1,kind='oak'):
    start(name);base=Vector((0,0,0));top=Vector((lean,.07,height*.72))
    beam_between('Main_trunk',base+Vector((0,0,.1)),top,radius,BARK,12)
    for j in range(5):
        z=height*(.40+j*.095);angle=2*math.pi*j/2.9
        end=Vector((math.cos(angle)*spread*.62,math.sin(angle)*spread*.62,z+height*.14))
        beam_between('Branch_%02d'%j,(lean*z/height,0,z),end,radius*(.55-j*.045),BARK)
    for i in range(clusters):
        a=2*math.pi*(i/clusters)+R.uniform(-.28,.28)
        r=spread*R.uniform(.23,.76);z=height*R.uniform(.68,.93)
        if kind=='birch': r*=.65;z=height*R.uniform(.55,.97)
        ico('Canopy_%02d'%i,(math.cos(a)*r,math.sin(a)*r,z),
            (spread*R.uniform(.29,.42),spread*R.uniform(.27,.4),height*R.uniform(.13,.18)),
            LEAF if i%3 else LEAF2,1,.24)
    ico('Canopy_Crown',(0,0,height*.89),(spread*.45,spread*.44,height*.17),LEAF,1,.2)

def rock(name,scale=(1,1,.6),m=STONE):
    start(name);ico('Irregular_stone',(0,0,scale[2]*.9),scale,m,2,.23)
    for i in range(3):
        ico('Small_chip_%d'%i,(R.uniform(-scale[0],scale[0]),R.uniform(-scale[1],scale[1]),.1),(.12,.17,.12),STONE2,1,.17)

def plant(name,height=.7,leaves=9,floral=False,ma=LEAF):
    start(name)
    for i in range(leaves):
        a=2*math.pi*i/leaves+R.uniform(-.2,.2);rad=R.uniform(.05,.16)
        x,y=math.cos(a)*rad,math.sin(a)*rad
        z=height*R.uniform(.54,.98)
        beam_between('Stem_%d'%i,(0,0,.03),(x,y,z),.013,GRASS,5)
        leaf('Leaf_%d'%i,(x*.45,y*.45,z*.52),(x*1.6,y*1.6,z*1.03),height*.18,ma)
        if floral:ico('Flower_%d'%i,(x,y,z),(.06,.06,.055),FLOWER if i%2 else PURPLE,1,.12)

def grass(name,height=.3,n=13):
    start(name)
    for i in range(n):
        a=R.uniform(0,math.tau);rr=R.uniform(.015,.24);x,y=rr*math.cos(a),rr*math.sin(a)
        h=height*R.uniform(.65,1.22)
        leaf('Blade_%02d'%i,(x,y,.01),(x+math.cos(a)*h*.24,y+math.sin(a)*h*.24,h),.035,GRASS if i%4 else GRASS2)

def stump(name='Stump_Old'):
    start(name);cyl('Trunk_stump',(0,0,.43),.47,.86,BARK,11)
    cyl('Cut_surface',(0,0,.875),.46,.06,WOODLIGHT,11)
    for i in range(4):
        a=i*math.tau/4
        beam_between('Root_%d'%i,(0,0,.15),(.85*math.cos(a),.85*math.sin(a),.09),.12,BARK)

def log(name='Log_Fallen'):
    start(name);beam_between('Fallen_trunk',(-2.2,0,.45),(2.2,.2,.42),.43,BARK,12)
    for i in range(3):
        beam_between('Broken_branch_%d'%i,(-1.5+i*1.5,0,.43),(-1.3+i*1.5,(-1)**i*.9,.72),.095,BARK)

def fence(name='Fence_Straight'):
    start(name)
    for x in (-.95,.95):
        cube('Post',(x,0,.62),(.15,.15,1.24),WOOD,.025)
        ico('Post_cap',(x,0,1.26),(.10,.10,.08),WOODLIGHT,1,.15)
    for z in (.43,.93):cube('Rail',(0,0,z),(2.1,.10,.13),WOOD,.02)
    for i,x in enumerate((-.55,-.1,.35,.73)):
        p=cube('Picket_%d'%i,(x,-.03,.67),(.14,.11,1.1+R.uniform(-.08,.07)),WOODLIGHT,.015)
        p.rotation_euler[1]=R.uniform(-.025,.025)

def bench():
    start('Bench_Rustic')
    for x in (-.62,.62):
        cube('Leg',(x,0,.30),(.12,.44,.6),WOOD,.025)
    for y in (-.19,0,.19):cube('Seat_board',(0,y,.67),(1.65,.17,.11),WOODLIGHT,.03)
    for x in (-.66,.66):cube('Back_post',(x,.26,.89),(.12,.12,.8),WOOD,.02)
    for z in (.96,1.20):cube('Back_rail',(0,.27,z),(1.5,.11,.13),WOODLIGHT,.025)

def crate():
    start('Crate_Stack')
    for i,(x,y,z) in enumerate(((0,0,0),(.58,.1,.05),(.25,.1,.56))):
        for axis in range(2):
            cube('Crate_%d_panel_%d'%(i,axis),(x,y,z+.27),(.52,.52,.54),WOODLIGHT,.025)
            break
        for dx in (-.24,.24):
            cube('Crate_%d_strap'%i,(x+dx,y,z+.28),(.05,.56,.54),WOOD,.012)

def signpost():
    start('Sign_Post');cyl('Post',(0,0,1.07),.085,2.14,WOOD,8)
    b=cube('Carved_direction',(0,.02,1.8),(1.5,.12,.33),WOODLIGHT,.025)
    # Distinct arrow silhouette with tip
    ico('Arrow_end',(.83,.02,1.8),(.25,.09,.19),WOODLIGHT,1,.04)
    cube('Crossbeam',(0,0,2.15),(.45,.14,.11),WOOD,.02)

def barrel():
    start('Barrel_Stack')
    for j,(x,y,z) in enumerate(((0,0,0),(.8,0,0),(.4,.1,.9))):
        cyl('Barrel_body_%d'%j,(x,y,z+.4),.32,.8,WOOD,12)
        for h in (.15,.62):cyl('Iron_hoop_%d'%j,(x,y,z+h),.342,.055,METAL,12)
        cyl('Barrel_lid_%d'%j,(x,y,z+.82),.31,.035,WOODLIGHT,12)

def ruin_stone():
    start('Rune_StandingStone')
    ico('Monolith',(0,0,1.08),(.5,.35,1.12),STONE,2,.15)
    # Raised geometric carved emblem, clearly visible from the game camera
    for i in range(3):cube('Carved_mark_%d'%i,(0,-.37,1.15+i*.27),(.18,.045,.035),WOODLIGHT,.005)
    for i in range(3):ico('Base_rubble_%d'%i,(R.uniform(-.5,.5),R.uniform(-.6,.6),.12),(.22,.23,.13),STONE2,1,.19)

def pillar():
    start('Ruin_PillarBroken')
    cube('Base',(0,0,.16),(1.1,1.1,.32),STONE,.06)
    cyl('Column',(0,0,.92),.35,1.4,STONE,10)
    ico('Broken_top',(0,0,1.65),(.45,.4,.18),STONE2,1,.27)
    for i in range(3):ico('Rubble_%d'%i,(R.uniform(-.8,.8),R.uniform(-.8,.8),.12),(.2,.27,.12),STONE2,1,.19)

def hay():
    start('Hay_BaleRound')
    o=cyl('Straw_roll',(0,0,.65),.65,1.25,STRAW,16);o.rotation_euler[0]=math.pi/2
    for y in (-.38,.38):
        # low-poly binding rope as a torus
        bpy.ops.mesh.primitive_torus_add(major_segments=16,minor_segments=4,location=(0,y,.65),major_radius=.65,minor_radius=.014)
        o=bpy.context.object;o.name='Binding';o.rotation_euler[0]=math.pi/2;put(o,WOOD)

def well():
    start('Well_Stone')
    for i in range(12):
        a=i*math.tau/12
        o=cube('Well_stone_%02d'%i,(.82*math.cos(a),.82*math.sin(a),.45),(.47,.35,.85),STONE if i%3 else STONE2,.05)
        o.rotation_euler[2]=a+math.pi/2
    for x in (-1,1):cube('Well_roof_post',(x,0,1.5),(.14,.14,2.5),WOOD,.02)
    cube('Roof_beam',(0,0,2.73),(2.25,.2,.15),WOOD,.03)
    for s in (-1,1):
        o=cube('Roof_slope',(0,s*.42,2.92),(2.4,1.05,.11),WOODLIGHT,.035);o.rotation_euler[0]=s*.35

def flower_shrub():
    start('Shrub_Berry')
    for i in range(7):
        a=i*math.tau/7
        ico('Leaf_mass_%d'%i,(.42*math.cos(a),.42*math.sin(a),.63+R.uniform(-.13,.2)),(.52,.48,.48),LEAF if i%2 else LEAF2,1,.22)
    for i in range(12):
        a=R.uniform(0,math.tau);r=R.uniform(.3,.68)
        ico('Berry_%d'%i,(r*math.cos(a),r*math.sin(a),R.uniform(.6,1.02)),(.06,.055,.055),RED,1,.1)

# 23 initial sample models. All are deliberately prototypes for art direction review.
trunk_tree('Oak_Mature',9,.43,3.3,10,.18)
trunk_tree('Oak_Young',5,.22,1.8,8,.07)
trunk_tree('Birch_Young',5.5,.16,1.3,8,.1,'birch')
flower_shrub()
plant('Fern_Large',.95,12,False,LEAF)
plant('Herb_Broad',.52,8,False,LEAF2)
plant('Flower_White',.48,7,True,LEAF)
grass('Grass_TuftShort',.25,16)
grass('Grass_TuftTall',.58,22)
rock('Rock_FieldSmall',(.37,.29,.27))
rock('Rock_Boulder',(1.45,1.25,1.1))
rock('Rock_Mossy',(.94,.72,.71),STONE2)
stump();log();fence();bench();crate();signpost();barrel();ruin_stone();pillar();hay();well()

# Staging layout is only for reviewing the collection in Blender, not world placement.
# Each collection's individual meshes retain their local origins; objects moved for
# review must be returned to the origin before export.
for i,(name,arr) in enumerate(objects.items()):
    x=(i%6)*7.0;y=(i//6)*8.0
    for o in arr:o.location.x+=x;o.location.y+=y

scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene.render.engine='CYCLES';scene.render.resolution_x=1600;scene.render.resolution_y=1000
world=bpy.data.worlds.new('WL_ReviewWorld') if not bpy.data.worlds else bpy.data.worlds[0]
scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Strength'].default_value=.75
# No cameras/render claims: geometry review in viewport is the primary deliverable.
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
out=Path(args[0]) if args else Path.home()/'Desktop'/'Westland_StarterAssets.blend'
out.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(out))
print('Saved Blender STARTER asset source:',out,'Collections:',len(objects))
