# PokeMonster – Westland-Objektbibliothek (Vorbereitung V1)

**Stand:** 09.10.2026 – Planung und portable Ausgangsdaten, **noch nicht in Blender ausgeführt oder in Unreal importiert**. Diese Dateien wurden unabhängig vom Mac-Projekt erstellt. Sie verändern weder `Dev_WestlandRegion.umap` noch das Git-Repository.

## Lieferumfang

- `Westland_AssetCatalog.json` – **74 definierte Objekt-Typen**, mit Größen, Biomen, Priorität, Collision- und Instanzierungsabsicht.
- `Westland_AssetCatalog.csv` – gleicher Katalog zur Kontrolle und späteren Anpassung.
- `Build_Westland_StarterAssets.py` – optionales Blender-Python-Startskript für **23 prozedurale geometrische Basisobjekte** (Baum-/Pflanzen-/Stein-/Dorf-/Ruinenbeispiele). Es erzeugt eine separate `.blend`-Datei mit 23 Objekt-Collections in einer Review-Anordnung. **Nur Ausgangsformen**, keine fertigen hochwertigen Assets. Shader sind Blender-Vorschau und nicht Unreal-taugliche Textur-Bakes. Script-Syntax wurde geprüft; Blender-Laufzeit/Look konnte hier nicht getestet werden.
- `CODEX_AUFTRAG.md` – Auftrag für Codex, die Bibliothek später auf dem Mac mit vorhandenen Projektassets und Referenzen in Produktion zu bringen.

## Gestaltungsstandard

**Stil:** moderne, hochauflösende, malerische 2.5D-Fantasygrafik, handgemalte Farb- und Formvariation, organische Silhouetten, warmes ländliches Westland. Kein Pixel-Art, keine fotorealistischen Fototexturen, keine geometrischen Platzhalter als Endergebnis. Primär sind die bisherigen Westland-/Heilhaus-Referenzbilder und die tatsächliche Unreal-Spielkamera.

**Maßstab:** Blender 1 Einheit = 1 Meter; Unreal 1 m = 100 cm. Spieler ist 1,40 m hoch. Außenkamera 2500 cm, FOV 35°, Yaw −45°, Pitch −55°. Große Silhouetten, Blattmassen, Steinstruktur, Licht-/Schattenlesbarkeit müssen aus dieser Distanz funktionieren. Größen im Katalog sind **Designziele**, keine aus Referenzbildern gemessenen Fakten.

**Materialfamilien:** warmes Holz (dunkel/hell), Baumrinde, sommerliches Blattgrün (2–3 Farbfamilien), trockene Grasakzente, warmgrauer Naturstein, moosiger Stein, erdige Metalltöne, Stroh, Blumenakzente. Bei Unreal-Import Materialinstanzen/Atlanten bzw. wenige Mastermaterialien bevorzugen; Procedural Blender Nodes nicht ungebacken als FBX-Texturen voraussetzen.

**Modellqualität:** von grob nach fein: Silhouette → glaubwürdige Form/Proportion → Materialvariation → spielkamerarelevante Details. Bevels/Weighted Normals, saubere UVs, Pivots am Boden, angewendete Transforms, saubere Benennung, einfache Collision, LOD/Culling. Variation darf nicht nur Skalierung desselben Meshs sein.

## Biome/Verteilung

- **Dorf/Heilhaus:** kleinere Obstbäume, Blüten, Nutzgegenstände, geordnete Vegetation; Türen und Wege frei.
- **Wiesen:** Gras in unterschiedlicher Dichte über **Teile der Flächen**, Wildblumen und Sträucher in Gruppen, dazwischen sichtbarer gemalter Boden.
- **Fluss:** Weiden, Schilf, Ufersteine, Wurzeln und Schwemmholz; keine Objekte im Brückenlaufweg.
- **Wald/Waldrand:** ältere Bäume, Farn, Moos, Wurzeln, Totholz, Buschgruppen und offene Lichtungen.
- **Mühle/Felder:** Zäune, Felder, Werkzeuge, Heu, Wagen und Nutzgegenstände.
- **Ruinen/Steinkreis:** überwachsene, aber lesbare Steinstrukturen; sparsame Symbole statt austauschbarer Fantasyornamente.

**Performance:** Aktueller Regionsbericht nennt 26,33 FPS in Editor-PIE (Medium, 75 % Auflösung). Deshalb vor flächendeckender Instanzierung einen messbaren Baseline-Vergleich PIE vs Standalone und CPU/GPU-Engpassanalyse durchführen. Kein erfundener fester Polygon- oder Instanzengrenzwert: nach Profiling festlegen. HISM/ISM nur für geeignete Wiederholungen; Schatten und Collision selektiv. Kein ungeprüftes Massen-Placement.

## Optionales lokales Blender-Startskript

1. ZIP auf dem Mac entpacken (außerhalb des Unreal-Repositories oder in einem separaten Arbeitsverzeichnis).
2. **Nach der Git-Sicherung der Region V1** Codex zuerst den Katalog und den Auftrag lesen lassen.
3. Wenn die prozeduralen Grundformen als Basis erwünscht sind, mit Blender ausführen:

```bash
/Applications/Blender.app/Contents/MacOS/Blender -b -t 4 \
  --python Build_Westland_StarterAssets.py -- \
  "$HOME/Desktop/Westland_StarterAssets.blend"
```

4. `.blend` in Blender öffnen und **Formen, Ausrichtung, Materialien und Größen** prüfen. Nicht ohne Art-Review in die Hauptkarte importieren.
5. Erst danach hochwertige Meshes, UVs, Texturen, Unreal-Materialien, Collision/LOD und eine kleine Referenzzone in der Map entwickeln.

## Git-Sicherheit

Die aktuelle Region V1 mit 173 uncommitteten Dateien muss **zuerst separat gesichert** werden. Nicht in einem Commit mit neuen Assets vermischen. Für neue Assets: `git status --short`, Dateiliste prüfen, gezielt stagen, vor Commit visuell und technisch testen. Review-Screenshots, Blender-Backups und `Saved/` nicht einchecken.
